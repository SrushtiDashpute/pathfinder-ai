// For local development this points to the Express server.
// When deployed, change this to your public backend URL, e.g.
// https://your-pathfinder-api.example.com
const API_BASE = "http://localhost:3000";

async function askAI(payload) {
  const response = await fetch(`${API_BASE}/api/ask`, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "AI request failed.");
  return data.answer;
}

function setLoading(button, loading, text) {
  button.disabled = loading;
  button.textContent = loading ? "Thinking..." : text;
  button.classList.toggle("loading", loading);
}

document.getElementById("quizForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  const button = document.getElementById("quizBtn");
  const box = document.getElementById("quizResult");
  box.classList.remove("hidden");
  box.textContent = "Preparing your personalized recommendation...";
  setLoading(button, true, "Get My Career Recommendation");

  try {
    const answer = await askAI({
      type: "career",
      interest: form.get("interest"),
      strength: form.get("strength"),
      environment: form.get("environment"),
      education: form.get("education"),
      notes: form.get("notes")
    });
    box.textContent = answer;
  } catch (err) {
    box.textContent = "Sorry, we couldn't generate the recommendation. " + err.message;
  } finally {
    setLoading(button, false, "Get My Career Recommendation");
  }
});

document.getElementById("contactForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  const button = document.getElementById("contactBtn");
  const box = document.getElementById("contactResult");
  box.classList.remove("hidden");
  box.textContent = "Generating a clear answer...";
  setLoading(button, true, "Get AI Answer");

  try {
    const answer = await askAI({
      type: "question",
      name: form.get("name"),
      education: form.get("education"),
      question: form.get("question")
    });
    box.textContent = answer;
  } catch (err) {
    box.textContent = "Sorry, we couldn't answer right now. " + err.message;
  } finally {
    setLoading(button, false, "Get AI Answer");
  }
});
