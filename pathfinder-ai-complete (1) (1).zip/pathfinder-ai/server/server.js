import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.GEMINI_API_KEY) {
  console.error("Missing GEMINI_API_KEY in server/.env");
  process.exit(1);
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

app.use(cors());
app.use(express.json({ limit: "20kb" }));

const SYSTEM = `
You are PathFinder, a friendly Indian college and career guidance assistant.
Give accurate, practical, easy-to-read answers for students.
Do not pretend to know a student's exact admission eligibility, college cutoff,
salary, fees or current government rules unless the user supplies the information.
When current facts are needed, clearly say they should be verified on the official
college/government website.
Use short headings and bullet points. Avoid unnecessary emojis.
Never guarantee a career outcome. Encourage the student to compare options.
`;

app.get("/api/health", (req,res) => res.json({ok:true}));

app.post("/api/ask", async (req,res) => {
  try {
    const body = req.body || {};
    let prompt = "";

    if (body.type === "career") {
      prompt = `
A student completed this career quiz:
Interest: ${body.interest || "Not provided"}
Strength: ${body.strength || "Not provided"}
Preferred environment: ${body.environment || "Not provided"}
Education level: ${body.education || "Not provided"}
Extra notes: ${body.notes || "None"}

Create a personalized career recommendation.
Return exactly these sections:
1. Best-fit career areas
2. Why they fit
3. Suggested courses/skills
4. A simple 6-month roadmap
5. 2-3 alternative careers
6. Important note

Keep it clear and student-friendly. Do not claim this is a scientific diagnosis.
`;
    } else if (body.type === "question") {
      prompt = `
Student name: ${body.name || "Student"}
Education level: ${body.education || "Not provided"}
Question: ${body.question || "No question"}

Answer the student's question directly. If the answer depends on current
admission rules, fees, dates, cutoffs or other changing information, say so and
tell the student what official source they should verify.
`;
    } else {
      return res.status(400).json({error:"Invalid request type."});
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: SYSTEM,
        temperature: 0.4,
        maxOutputTokens: 900
      }
    });

    res.json({answer: response.text || "No answer was generated."});
  } catch (error) {
    console.error(error);
    res.status(500).json({error:"AI service error. Check the server/API key and try again."});
  }
});

app.listen(PORT, () => {
  console.log(`PathFinder AI server running at http://localhost:${PORT}`);
});
