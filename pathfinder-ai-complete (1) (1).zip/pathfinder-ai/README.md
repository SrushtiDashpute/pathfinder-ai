# PathFinder + AI — clean working starter

This is a complete small version of the website shown in the screenshots:
- Home / Explore / Career Quiz / Contact
- Responsive clean design
- AI career recommendations
- AI answers to student questions
- API key kept on the server (not exposed in the browser)

## 1. Install Node.js
Install a current Node.js LTS release.

## 2. Get a Gemini API key
Create a key in Google AI Studio. Never paste the key into `app.js` or commit it to GitHub.

## 3. Start the AI backend

Open a terminal:

    cd pathfinder-ai/server
    npm install

Copy `.env.example` to `.env` and put your key inside:

    GEMINI_API_KEY=YOUR_KEY_HERE

Then:

    npm start

You should see:

    PathFinder AI server running at http://localhost:3000

## 4. Run the website locally

From the main `pathfinder-ai` folder, use any static server. Easiest:

    npx serve .

Then open the address it gives you.

The frontend currently calls:
    http://localhost:3000

If you use a different backend URL, edit `API_BASE` at the top of `app.js`.

## 5. Test

First open:
    http://localhost:3000/api/health

It should show:
    {"ok":true}

Then use Career Quiz and Contact.

## 6. Deploy

IMPORTANT: GitHub Pages can host the HTML/CSS/JS but cannot safely run the Node/Express AI backend.

Recommended structure:
- Frontend: GitHub Pages
- Backend: a Node-compatible host such as Render, Railway, Fly.io, or another server platform.

After deploying the backend, change:

    const API_BASE = "http://localhost:3000";

to your HTTPS backend URL in `app.js`, then push the frontend to GitHub Pages.

## Security checklist

- Keep `.env` out of Git.
- Add `server/.env` to `.gitignore`.
- Never put `GEMINI_API_KEY` in `app.js`, HTML, or public GitHub files.
- For a real public website, add rate limiting, input limits, logging and abuse protection.
- For college cutoffs, fees and admission dates, link users to official sources rather than letting AI invent current facts.
